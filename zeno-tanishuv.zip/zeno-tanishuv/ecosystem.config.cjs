module.exports = {
  apps: [{
    name: 'zeno-tanishuv',
    script: 'src/index.js',
    instances: 1,
    autorestart: true,
    max_restarts: 50,
    restart_delay: 3000,
    env: { NODE_ENV: 'production' },
  }],
};
