import 'dotenv/config';

function need(name) {
  const v = process.env[name];
  if (!v) {
    console.error(`❌ .env faylida ${name} ko‘rsatilmagan`);
    process.exit(1);
  }
  return v;
}
const num = (name, def) => Number(process.env[name] ?? def);

export const config = {
  botToken: need('BOT_TOKEN'),
  adminIds: (process.env.ADMIN_IDS || '').split(',').map((s) => Number(s.trim())).filter(Boolean),
  support: (process.env.SUPPORT_USERNAME || '').replace('@', ''),
  webhook: {
    domain: process.env.WEBHOOK_DOMAIN || '',
    port: num('PORT', 3000),
    secret: process.env.WEBHOOK_SECRET || 'zeno_secret_2026',
  },
  limits: {
    free: { views: num('FREE_DAILY_VIEWS', 30), likes: num('FREE_DAILY_LIKES', 15), favorites: 10 },
    premium: { views: num('PREMIUM_DAILY_VIEWS', 300), likes: num('PREMIUM_DAILY_LIKES', 150), favorites: 200 },
  },
  products: {
    P7: { title: 'ZENO Premium — 7 kun', days: 7, stars: num('PRICE_P7', 150) },
    P30: { title: 'ZENO Premium — 30 kun', days: 30, stars: num('PRICE_P30', 450) },
    P90: { title: 'ZENO Premium — 90 kun', days: 90, stars: num('PRICE_P90', 1100) },
    BOOST: { title: 'Profilni yuqoriga chiqarish (3 soat)', hours: 3, stars: num('PRICE_BOOST', 50) },
  },
  broadcastCooldownMin: num('BROADCAST_COOLDOWN_MIN', 30),
  reportAutoHide: num('REPORT_AUTOHIDE', 3),
};
