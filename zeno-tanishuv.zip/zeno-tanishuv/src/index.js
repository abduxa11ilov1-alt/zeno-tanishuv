import { Telegraf } from 'telegraf';
import { config } from './config.js';
import { prisma } from './db.js';
import { rateLimit, loadUser } from './middlewares.js';
import * as menu from './handlers/menu.js';
import * as profile from './handlers/profile.js';
import * as search from './handlers/search.js';
import * as browse from './handlers/browse.js';
import * as lists from './handlers/lists.js';
import * as chat from './handlers/chat.js';
import * as report from './handlers/report.js';
import * as premium from './handlers/premium.js';
import * as settings from './handlers/settings.js';
import * as admin from './handlers/admin.js';
import * as router from './handlers/router.js';

const bot = new Telegraf(config.botToken, { handlerTimeout: 90_000 });

bot.catch(async (err, ctx) => {
  console.error(`❌ Xato [${ctx.updateType}]:`, err);
  try {
    if (ctx.callbackQuery) await ctx.answerCbQuery('⚠️ Xatolik yuz berdi, qayta urinib ko‘ring.', { show_alert: true });
    else await ctx.reply('⚠️ Kutilmagan xatolik yuz berdi. Birozdan so‘ng qayta urinib ko‘ring.');
  } catch { /* e'tiborsiz */ }
});

bot.use(rateLimit);
bot.use(loadUser);

// Tartib muhim: router eng oxirida
[menu, profile, search, browse, lists, chat, report, premium, settings, admin, router].forEach((m) => m.register(bot));

process.on('unhandledRejection', (e) => console.error('unhandledRejection:', e));
process.on('uncaughtException', (e) => console.error('uncaughtException:', e));

async function shutdown(sig) {
  console.log(`\n${sig} — bot to‘xtatilmoqda...`);
  try { bot.stop(sig); } catch { /* bot hali ishga tushmagan bo'lishi mumkin */ }
  await prisma.$disconnect();
  process.exit(0);
}
process.once('SIGINT', () => shutdown('SIGINT'));
process.once('SIGTERM', () => shutdown('SIGTERM'));

async function main() {
  await prisma.$connect();
  console.log('✅ Ma’lumotlar bazasiga ulandi');

  await bot.telegram.setMyCommands([
    { command: 'start', description: 'Botni ishga tushirish' },
    { command: 'menu', description: 'Asosiy menyu' },
    { command: 'help', description: 'Yordam' },
  ]);
  const me = await bot.telegram.getMe();
  console.log(`🚀 ZENO TANISHUV ishga tushdi: @${me.username}`);

  if (config.webhook.domain) {
    await bot.launch({
      webhook: {
        domain: config.webhook.domain,
        port: config.webhook.port,
        hookPath: `/tg/${config.webhook.secret}`,
        secretToken: config.webhook.secret,
      },
    });
  } else {
    await bot.telegram.deleteWebhook();
    await bot.launch();
  }
}

main().catch((e) => {
  console.error('❌ Ishga tushmadi:', e);
  process.exit(1);
});
