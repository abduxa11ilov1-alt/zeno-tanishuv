import { prisma } from '../db.js';
import { b, ikb, HTML, profileCaption, cardKb } from '../ui.js';
import { esc, safe, setUser } from '../utils.js';
import { nextCandidate, likeUser, limitsFor } from '../services/matching.js';
import { showLiked, showReceived, showFavs } from './lists.js';

export async function sendCard(ctx, target, mode) {
  const kb = cardKb(target.id, mode);
  try {
    return await ctx.replyWithPhoto(target.photoId, { caption: profileCaption(target), ...HTML, protect_content: true, ...kb });
  } catch {
    return ctx.reply(profileCaption(target), { ...HTML, ...kb });
  }
}

export async function showNext(ctx, mode) {
  const me = ctx.user;
  const lim = limitsFor(me);
  if (me.viewsToday >= lim.views) {
    return ctx.reply(
      `⏳ Bugungi profil ko‘rish limiti tugadi (<b>${lim.views}</b> ta).\n\n💎 Premium bilan ko‘proq profil ko‘ring yoki ertaga qaytib keling.`,
      { ...HTML, ...ikb([[b('💎 Premium olish', 'prem:open')]]) },
    );
  }
  const t = await nextCandidate(me, mode === 's');
  if (!t) {
    return ctx.reply(mode === 's'
      ? '😔 Filtrlaringizga mos yangi profil topilmadi.\nFiltrlarni o‘zgartirib ko‘ring («🔍 Odamlarni qidirish»).'
      : '😔 Hozircha yangi profillar yo‘q.\nKeyinroq qaytib keling — yangi insonlar har kuni qo‘shiladi 💜');
  }
  await setUser(ctx, { viewsToday: { increment: 1 } });
  return sendCard(ctx, t, mode);
}

async function announceMatch(ctx, me, target, match) {
  const kb = ikb([[b('💬 Suhbatni boshlash', `chat:${match.id}`)]]);
  const text = (n) => `🎉 <b>O‘zaro moslik!</b>\n\nSiz va <b>${esc(n)}</b> bir-biringizni yoqtirdingiz 💜\nEndi suhbatni boshlashingiz mumkin.`;
  const send = (chatId, photo, name) => ctx.telegram.sendPhoto(chatId, photo, { caption: text(name), ...HTML, ...kb })
    .catch(() => ctx.telegram.sendMessage(chatId, text(name), { ...HTML, ...kb }));
  await safe(() => send(ctx.from.id, target.photoId, target.name));
  await safe(() => send(Number(target.tgId), me.photoId, me.name));
}

async function notifyLiked(ctx, target) {
  const last = target.lastLikeNotifyAt?.getTime() || 0;
  if (!target.notify || Date.now() - last < 3 * 3600 * 1000) return; // spam bo‘lmasligi uchun 3 soatda 1 marta
  await prisma.user.update({ where: { id: target.id }, data: { lastLikeNotifyAt: new Date() } });
  await safe(() => ctx.telegram.sendMessage(Number(target.tgId),
    '💌 <b>Sizni kimdir yoqtirdi!</b>\n\nKim ekanini «💌 Menga yoqqanlar» bo‘limida ko‘rishingiz mumkin.', HTML));
}

const backToList = (ctx, mode) => ({ L: showLiked, F: showFavs, R: showReceived }[mode]?.(ctx, 0));

export function register(bot) {
  bot.action(/^lk:(\d+):(\w)$/, async (ctx) => {
    const id = Number(ctx.match[1]);
    const mode = ctx.match[2];
    const me = ctx.user;
    const lim = limitsFor(me);
    if (me.likesToday >= lim.likes) {
      return ctx.answerCbQuery(`❗ Kunlik yoqtirish limiti (${lim.likes}) tugadi. 💎 Premium bilan oshiring.`, { show_alert: true });
    }
    const res = await likeUser(me, id);
    await ctx.deleteMessage().catch(() => {});
    if (res.status === 'gone') {
      await ctx.answerCbQuery('Bu profil mavjud emas');
    } else if (res.status !== 'already') {
      await setUser(ctx, { likesToday: { increment: 1 } });
      await ctx.answerCbQuery('❤️ Yoqdi!');
      if (res.status === 'match') await announceMatch(ctx, me, res.target, res.match);
      else await notifyLiked(ctx, res.target);
    } else await ctx.answerCbQuery();
    if (mode === 'b' || mode === 's') return showNext(ctx, mode);
    return backToList(ctx, mode);
  });

  bot.action(/^sk:(\d+):(\w)$/, async (ctx) => {
    const id = Number(ctx.match[1]);
    const mode = ctx.match[2];
    await prisma.swipe.upsert({
      where: { fromId_toId: { fromId: ctx.user.id, toId: id } },
      create: { fromId: ctx.user.id, toId: id, type: 'SKIP' },
      update: {},
    }).catch(() => {});
    await ctx.answerCbQuery('👎');
    await ctx.deleteMessage().catch(() => {});
    if (mode === 'b' || mode === 's') return showNext(ctx, mode);
    return backToList(ctx, mode);
  });

  bot.action(/^fv:(\d+):(\w)$/, async (ctx) => {
    const me = ctx.user;
    const id = Number(ctx.match[1]);
    const key = { ownerId_targetId: { ownerId: me.id, targetId: id } };
    if (await prisma.favorite.findUnique({ where: key })) return ctx.answerCbQuery('⭐ Bu profil allaqachon sevimlilarda');
    const max = limitsFor(me).favorites;
    if (await prisma.favorite.count({ where: { ownerId: me.id } }) >= max) {
      return ctx.answerCbQuery(`❗ Sevimlilar limiti (${max}) to‘lgan. 💎 Premium bilan oshiring.`, { show_alert: true });
    }
    await prisma.favorite.create({ data: { ownerId: me.id, targetId: id } }).catch(() => {});
    return ctx.answerCbQuery('⭐ Sevimlilarga qo‘shildi!');
  });

  bot.action(/^fd:(\d+)$/, async (ctx) => {
    await prisma.favorite.deleteMany({ where: { ownerId: ctx.user.id, targetId: Number(ctx.match[1]) } });
    await ctx.answerCbQuery('🗑 Olib tashlandi');
    await ctx.deleteMessage().catch(() => {});
    return showFavs(ctx, 0);
  });

  bot.action(/^ul:(\d+)$/, async (ctx) => {
    const me = ctx.user;
    const id = Number(ctx.match[1]);
    const m = await prisma.match.findFirst({ where: { active: true, OR: [{ aId: me.id, bId: id }, { aId: id, bId: me.id }] } });
    if (m) return ctx.answerCbQuery('❗ Sizda o‘zaro moslik bor. Suhbatni «💬 Suhbatlarim» orqali to‘xtating.', { show_alert: true });
    await prisma.swipe.deleteMany({ where: { fromId: me.id, toId: id, type: 'LIKE' } });
    await ctx.answerCbQuery('💔 Bekor qilindi');
    await ctx.deleteMessage().catch(() => {});
    return showLiked(ctx, 0);
  });
}
