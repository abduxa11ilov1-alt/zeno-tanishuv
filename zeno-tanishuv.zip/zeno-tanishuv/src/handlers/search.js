import { setUser, isPremium } from '../utils.js';
import { b, ikb, HTML, LOOK_TXT } from '../ui.js';
import { askStep } from './profile.js';
import { showNext } from './browse.js';

const NEXT_G = { ALL: 'MALE', MALE: 'FEMALE', FEMALE: 'ALL' };

export async function showSearch(ctx, edit = false) {
  const u = ctx.user;
  const lock = isPremium(u) ? '' : ' 🔒';
  const text = [
    '🔍 <b>Qidiruv filtrlari</b>',
    '',
    `🎂 Yosh: <b>${u.fMinAge}–${u.fMaxAge}</b>`,
    `🚻 Jins: <b>${LOOK_TXT[u.fGender]}</b>`,
    `📍 Viloyat: <b>${u.fRegion || 'Hammasi'}</b>`,
    `🏘 Shahar/tuman${lock}: <b>${u.fDistrict || 'Hammasi'}</b>`,
    `🎯 Qiziqishlar${lock}: <b>${u.fInterests.length ? u.fInterests.join(', ') : 'Hammasi'}</b>`,
    '',
    isPremium(u) ? '' : '<i>🔒 Tuman va qiziqish bo‘yicha qidiruv 💎 Premium uchun.</i>',
  ].join('\n');
  const kb = ikb([
    [b('🎂 Yosh oralig‘i', 'sf:AGERANGE'), b('🚻 Jins', 'sf:GENDER')],
    [b('📍 Viloyat', 'sf:REGION'), b(`🏘 Tuman${lock}`, 'sf:DISTRICT')],
    [b(`🎯 Qiziqishlar${lock}`, 'sf:INTERESTS')],
    [b('♻️ Tozalash', 'sf:clear'), b('🔍 Qidirishni boshlash', 'sf:go')],
  ]);
  if (edit) return ctx.editMessageText(text, { ...HTML, ...kb }).catch(() => {});
  return ctx.reply(text, { ...HTML, ...kb });
}

export function register(bot) {
  bot.action(/^sf:(\w+)$/, async (ctx) => {
    const k = ctx.match[1];
    const u = ctx.user;
    if (k === 'GENDER') {
      await setUser(ctx, { fGender: NEXT_G[u.fGender] });
      await ctx.answerCbQuery();
      return showSearch(ctx, true);
    }
    if (k === 'clear') {
      await setUser(ctx, { fMinAge: 18, fMaxAge: 60, fGender: 'ALL', fRegion: null, fDistrict: null, fInterests: [] });
      await ctx.answerCbQuery('♻️ Filtrlar tozalandi');
      return showSearch(ctx, true);
    }
    if (k === 'go') {
      await ctx.answerCbQuery();
      return showNext(ctx, 's');
    }
    if ((k === 'DISTRICT' || k === 'INTERESTS') && !isPremium(u)) {
      return ctx.answerCbQuery('💎 Kengaytirilgan qidiruv faqat Premium uchun', { show_alert: true });
    }
    if (['AGERANGE', 'REGION', 'DISTRICT', 'INTERESTS'].includes(k)) {
      await ctx.answerCbQuery();
      await setUser(ctx, { state: `search:${k}`, stateData: null });
      return askStep(ctx, k, 'search');
    }
    return ctx.answerCbQuery();
  });
}
