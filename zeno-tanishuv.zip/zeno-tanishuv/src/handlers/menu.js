import { prisma } from '../db.js';
import { MENU, HTML, mainMenu } from '../ui.js';
import { clearState } from '../utils.js';
import { startRegistration, sendMyProfile, showEditMenu } from './profile.js';
import { showNext } from './browse.js';
import { showSearch } from './search.js';
import { showLiked, showReceived, showFavs } from './lists.js';
import { showChats } from './chat.js';
import { showSettings } from './settings.js';
import { showPremium } from './premium.js';

export const MENU_HANDLERS = {
  [MENU.START]: (ctx) => showNext(ctx, 'b'),
  [MENU.SEARCH]: (ctx) => showSearch(ctx),
  [MENU.PROFILE]: (ctx) => sendMyProfile(ctx),
  [MENU.EDIT]: (ctx) => showEditMenu(ctx),
  [MENU.LIKED]: (ctx) => showLiked(ctx, 0),
  [MENU.RECEIVED]: (ctx) => showReceived(ctx, 0),
  [MENU.CHATS]: (ctx) => showChats(ctx),
  [MENU.FAVS]: (ctx) => showFavs(ctx, 0),
  [MENU.SETTINGS]: (ctx) => showSettings(ctx),
  [MENU.PREMIUM]: (ctx) => showPremium(ctx),
};

const HELP = `💜 <b>ZENO TANISHUV</b> — yordam

❤️ <b>Tanishuvni boshlash</b> — profillarni ko‘ring va yoqtiring
🔍 <b>Qidirish</b> — yosh, jins, hudud bo‘yicha filtr
💌 <b>Menga yoqqanlar</b> — sizni yoqtirganlar
💬 <b>Suhbatlarim</b> — o‘zaro moslik bo‘lgan insonlar bilan yozishma
💎 <b>Premium</b> — qo‘shimcha imkoniyatlar

Buyruqlar: /start • /menu • /help`;

export function register(bot) {
  bot.start(async (ctx) => {
    if (!ctx.user.completed) return startRegistration(ctx);
    await clearState(ctx);
    return ctx.reply('💜 <b>ZENO TANISHUV</b> ga qaytganingizdan xursandmiz!\nMenyudan tanlang 👇', { ...HTML, ...mainMenu });
  });

  bot.command('menu', async (ctx) => {
    if (!ctx.user.completed) return startRegistration(ctx);
    await clearState(ctx);
    return ctx.reply('🏠 Asosiy menyu', mainMenu);
  });

  bot.command('help', (ctx) => ctx.reply(HELP, HTML));
}
