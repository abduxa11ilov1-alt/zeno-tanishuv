import { prisma } from '../db.js';
import { config } from '../config.js';
import { b, ikb, kbFor, HTML } from '../ui.js';
import { esc, notifyAdmins } from '../utils.js';
import { showNext } from './browse.js';
import { showLiked, showFavs, showReceived } from './lists.js';

export const REASONS = {
  1: 'Soxta profil', 2: 'Haqorat yoki spam', 3: 'Nomaqbul kontent',
  4: 'Firibgarlik yoki reklama', 5: 'Voyaga yetmagan shaxs', 6: 'Boshqa sabab',
};

export function register(bot) {
  bot.action(/^rp:(\d+):(\w+)$/, async (ctx) => {
    const [, id, src] = ctx.match;
    const rows = Object.entries(REASONS).map(([c, t]) => [b(t, `rr:${id}:${c}:${src}`)]);
    rows.push([b('⬅️ Orqaga', `bk:${id}:${src}`)]);
    await ctx.answerCbQuery('🚩 Sababni tanlang');
    return ctx.editMessageReplyMarkup(ikb(rows).reply_markup).catch(() => {});
  });

  bot.action(/^bk:(\d+):(\w+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    return ctx.editMessageReplyMarkup(kbFor(Number(ctx.match[1]), ctx.match[2]).reply_markup).catch(() => {});
  });

  bot.action(/^rr:(\d+):(\d):(\w+)$/, async (ctx) => {
    const me = ctx.user;
    const targetId = Number(ctx.match[1]);
    const code = ctx.match[2];
    const src = ctx.match[3];
    const reason = REASONS[code];
    const target = targetId !== me.id && reason ? await prisma.user.findUnique({ where: { id: targetId } }) : null;
    if (!target) return ctx.answerCbQuery('Xatolik');

    const dup = await prisma.report.findFirst({ where: { reporterId: me.id, targetId, status: 'PENDING' } });
    if (!dup) await prisma.report.create({ data: { reporterId: me.id, targetId, reason } });

    const distinct = (await prisma.report.groupBy({ by: ['reporterId'], where: { targetId, status: 'PENDING' } })).length;
    if (!target.hiddenByReports && (distinct >= config.reportAutoHide || code === '5')) {
      await prisma.user.update({ where: { id: targetId }, data: { hiddenByReports: true } });
      await notifyAdmins(ctx, `⚠️ <b>${esc(target.name)}</b> (#${target.id}) profili ${distinct} ta shikoyat sabab avtomatik yashirildi. /admin → 🚩 Shikoyatlar`);
    }

    if (src === 'b' || src === 's') {
      await prisma.swipe.upsert({
        where: { fromId_toId: { fromId: me.id, toId: targetId } },
        create: { fromId: me.id, toId: targetId, type: 'SKIP' }, update: {},
      }).catch(() => {});
    }

    await ctx.answerCbQuery('✅ Shikoyat qabul qilindi', { show_alert: src.startsWith('c') });
    if (src.startsWith('c')) { // suhbat ichida — kartochka qoladi
      return ctx.editMessageReplyMarkup(kbFor(targetId, src).reply_markup).catch(() => {});
    }
    await ctx.deleteMessage().catch(() => {});
    await ctx.reply('🚩 Shikoyatingiz qabul qilindi. Moderatorlar ko‘rib chiqadi. Rahmat!');
    if (src === 'b' || src === 's') return showNext(ctx, src);
    return ({ L: showLiked, F: showFavs, R: showReceived }[src]?.(ctx, 0));
  });
}
