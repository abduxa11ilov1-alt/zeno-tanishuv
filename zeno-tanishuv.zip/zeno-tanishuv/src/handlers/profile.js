import { Markup } from 'telegraf';
import { REGIONS, INTERESTS } from '../data.js';
import { setUser, getData, hasContactInfo, isPremium } from '../utils.js';
import { b, ikb, HTML, mainMenu, profileCaption, CONSENT_TEXT, GENDER_TXT, LOOK_TXT } from '../ui.js';
import { showSearch } from './search.js';

export const ORDER = ['NAME', 'AGE', 'GENDER', 'LOOKING', 'REGION', 'DISTRICT', 'INTERESTS', 'BIO', 'PHOTO'];
const NAME_RE = /^[\p{L}][\p{L}'‘’ʻ` -]{1,29}$/u;
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);

function interestsKb(sel, mode) {
  const rows = [];
  INTERESTS.forEach((t, i) => {
    const btn = b(sel.includes(i) ? `✅ ${t}` : t, `it:${i}`);
    if (i % 2 === 0) rows.push([btn]); else rows[rows.length - 1].push(btn);
  });
  rows.push([b('✔️ Tayyor', 'it:done')]);
  if (mode !== 'reg') rows.push([b('❌ Bekor qilish', 'cancel')]);
  return ikb(rows);
}

// ---------- Qadamni so‘rash ----------
export async function askStep(ctx, step, mode) {
  const u = ctx.user;
  const head = mode === 'reg' ? `📝 <b>${ORDER.indexOf(step) + 1}/${ORDER.length}-qadam</b>\n\n` : '';
  const cancel = mode === 'reg' ? [] : [[b('❌ Bekor qilish', 'cancel')]];
  const send = (text, rows = [], extra = {}) => {
    const all = [...rows, ...cancel];
    return ctx.reply(head + text, { ...HTML, ...(all.length ? ikb(all) : {}), ...extra });
  };

  switch (step) {
    case 'NAME':
      return send('✨ Ismingizni yozing:', [], mode === 'reg' ? Markup.removeKeyboard() : {});
    case 'AGE':
      return send('🎂 Yoshingizni yozing (faqat raqam, 18 dan katta bo‘lishi kerak):');
    case 'AGERANGE':
      return send('🎂 Yosh oralig‘ini yozing.\nMasalan: <code>20-30</code>');
    case 'GENDER':
      return send('🚻 Jinsingizni tanlang:', [[b(GENDER_TXT.MALE, 'gn:MALE'), b(GENDER_TXT.FEMALE, 'gn:FEMALE')]]);
    case 'LOOKING':
      return send('🎯 Kimni qidiryapsiz?', [[b(LOOK_TXT.MALE, 'lf:MALE'), b(LOOK_TXT.FEMALE, 'lf:FEMALE')], [b(LOOK_TXT.ALL, 'lf:ALL')]]);
    case 'REGION': {
      const rows = [];
      REGIONS.forEach((r, i) => {
        const btn = b(r, `rg:${i}`);
        if (i % 2 === 0) rows.push([btn]); else rows[rows.length - 1].push(btn);
      });
      if (mode === 'search') rows.push([b('🌍 Hammasi', 'rg:all')]);
      return send('📍 Viloyatingizni tanlang:', rows);
    }
    case 'DISTRICT':
      return send(mode === 'search'
        ? '🏘 Shahar yoki tuman nomini yozing (tozalash uchun «-» yuboring):'
        : '🏘 Shahar yoki tumaningizni yozing (masalan: Chilonzor):');
    case 'INTERESTS': {
      const cur = mode === 'search' ? u.fInterests : u.interests;
      const sel = cur.map((x) => INTERESTS.indexOf(x)).filter((i) => i >= 0);
      await setUser(ctx, { stateData: JSON.stringify({ sel }) });
      return ctx.reply(head + '🎨 Qiziqishlaringizni tanlang (5 tagacha):', { ...HTML, ...interestsKb(sel, mode) });
    }
    case 'BIO':
      return send('💬 O‘zingiz haqingizda qisqacha yozing (20–300 belgi).\n\n<i>Telefon raqam, havola va @username yozish mumkin emas.</i>');
    case 'PHOTO':
      return send('📸 Profil rasmingizni yuboring (yuzingiz aniq ko‘ringan haqiqiy rasm).');
  }
}

// ---------- Qadam tugagach: keyingisiga o‘tish yoki saqlash ----------
async function finish(ctx, mode, step, patch) {
  if (mode === 'search') {
    const map = {
      AGERANGE: (p) => ({ fMinAge: p.minAge, fMaxAge: p.maxAge }),
      REGION: (p) => ({ fRegion: p.region, fDistrict: null }),
      DISTRICT: (p) => ({ fDistrict: p.district }),
      INTERESTS: (p) => ({ fInterests: p.interests }),
    };
    await setUser(ctx, { ...map[step](patch), state: null, stateData: null });
    return showSearch(ctx);
  }

  if (mode === 'reg') {
    const next = ORDER[ORDER.indexOf(step) + 1];
    if (next) {
      await setUser(ctx, { ...patch, state: `reg:${next}`, stateData: null });
      return askStep(ctx, next, 'reg');
    }
    await setUser(ctx, { ...patch, state: null, stateData: null, completed: true });
    await ctx.reply('🎉 <b>Tabriklaymiz!</b> Profilingiz tayyor.\n\nEndi «❤️ Tanishuvni boshlash» tugmasini bosib, yangi insonlar bilan tanishing 💜', { ...HTML, ...mainMenu });
    return sendMyProfile(ctx);
  }

  // edit
  if (step === 'REGION') { // hudud o‘zgarsa, tuman ham yangilanadi
    await setUser(ctx, { ...patch, district: null, state: 'edit:DISTRICT', stateData: null });
    return askStep(ctx, 'DISTRICT', 'edit');
  }
  await setUser(ctx, { ...patch, state: null, stateData: null, ...(step === 'PHOTO' ? { verified: false } : {}) });
  await ctx.reply('✅ Profilingiz yangilandi!', mainMenu);
  return sendMyProfile(ctx);
}

// ---------- Matnli javoblar ----------
export async function onStepText(ctx, mode, step) {
  const t = ctx.message.text.trim();
  const bad = (m) => ctx.reply(`❗ ${m}`);

  switch (step) {
    case 'NAME':
      if (!NAME_RE.test(t)) return bad('Ism 2–30 ta harfdan iborat bo‘lsin (raqam va belgilarsiz).');
      return finish(ctx, mode, step, { name: cap(t) });
    case 'AGE': {
      if (!/^\d{1,2}$/.test(t)) return bad('Yoshni faqat raqam bilan yozing. Masalan: 24');
      const age = Number(t);
      if (age < 18) return ctx.reply('🔞 Kechirasiz, bot faqat 18 yosh va undan katta shaxslar uchun. Xavfsizlik uchun ro‘yxatdan o‘tish mumkin emas.');
      if (age > 70) return bad('Yosh 18 dan 70 gacha bo‘lishi kerak.');
      return finish(ctx, mode, step, { age });
    }
    case 'AGERANGE': {
      const m = t.match(/^(\d{2})\s*[-–]\s*(\d{2})$/);
      if (!m) return bad('Format: 20-30');
      const [minAge, maxAge] = [Number(m[1]), Number(m[2])];
      if (minAge < 18 || maxAge < minAge || maxAge > 80) return bad('Yosh oralig‘i 18 dan 80 gacha va to‘g‘ri bo‘lishi kerak.');
      return finish(ctx, mode, step, { minAge, maxAge });
    }
    case 'DISTRICT':
      if (mode === 'search' && t === '-') return finish(ctx, mode, step, { district: null });
      if (t.length < 2 || t.length > 40 || hasContactInfo(t)) return bad('Tuman/shahar nomi 2–40 belgidan iborat bo‘lsin.');
      return finish(ctx, mode, step, { district: cap(t) });
    case 'BIO':
      if (t.length < 20 || t.length > 300) return bad(`Matn 20–300 belgi bo‘lsin (hozir: ${t.length}).`);
      if (hasContactInfo(t)) return bad('Telefon raqam, havola yoki @username yozish mumkin emas.');
      return finish(ctx, mode, step, { bio: t });
    case 'PHOTO':
      return bad('Iltimos, rasm yuboring (fayl emas, oddiy rasm).');
    default:
      return ctx.reply('👆 Yuqoridagi tugmalardan birini tanlang.');
  }
}

export async function onPhoto(ctx, mode) {
  const photo = ctx.message.photo.at(-1);
  return finish(ctx, mode, 'PHOTO', { photoId: photo.file_id });
}

// ---------- Ro‘yxatdan o‘tishni boshlash ----------
export async function startRegistration(ctx) {
  const u = ctx.user;
  if (!u.consent) {
    return ctx.reply(CONSENT_TEXT, { ...HTML, ...ikb([[b('✅ Roziman, 18 yoshdan oshganman', 'consent:y')], [b('❌ Rozi emasman', 'consent:n')]]) });
  }
  const step = u.state?.startsWith('reg:') ? u.state.split(':')[1] : 'NAME';
  await setUser(ctx, { state: `reg:${step}` });
  return askStep(ctx, step, 'reg');
}

export async function sendMyProfile(ctx) {
  const u = ctx.user;
  const status = `\n\n${isPremium(u) ? '💎 Premium faol' : '🆓 Bepul tarif'} • ${u.verified ? '✅ Tasdiqlangan' : '⏳ Tekshiruvda'}\n🎯 Qidiraman: ${LOOK_TXT[u.lookingFor]}`;
  return ctx.replyWithPhoto(u.photoId, { caption: profileCaption(u) + status, ...HTML, ...ikb([[b('✏️ Tahrirlash', 'em')]]) });
}

export async function showEditMenu(ctx) {
  return ctx.reply('✏️ <b>Profilni tahrirlash</b>\n\nNimani o‘zgartirmoqchisiz?', {
    ...HTML,
    ...ikb([
      [b('📝 Ism', 'ed:NAME'), b('🎂 Yosh', 'ed:AGE')],
      [b('🚻 Jins', 'ed:GENDER'), b('🎯 Kimni qidiraman', 'ed:LOOKING')],
      [b('📍 Viloyat', 'ed:REGION'), b('🏘 Tuman/shahar', 'ed:DISTRICT')],
      [b('🎨 Qiziqishlar', 'ed:INTERESTS'), b('💬 O‘zim haqimda', 'ed:BIO')],
      [b('📸 Profil rasmi', 'ed:PHOTO')],
    ]),
  });
}

// ---------- Callback’lar ----------
const stateOf = (ctx) => (ctx.user.state || '').split(':');

export function register(bot) {
  bot.action(/^consent:(y|n)$/, async (ctx) => {
    await ctx.answerCbQuery();
    await ctx.deleteMessage().catch(() => {});
    if (ctx.match[1] === 'n') return ctx.reply('Tushunarli. Rozilik bermasangiz, botdan foydalana olmaysiz. Fikringiz o‘zgarsa /start ni bosing.');
    await setUser(ctx, { consent: true, state: 'reg:NAME' });
    return askStep(ctx, 'NAME', 'reg');
  });

  bot.action('em', async (ctx) => { await ctx.answerCbQuery(); return showEditMenu(ctx); });

  bot.action(/^ed:(\w+)$/, async (ctx) => {
    const step = ctx.match[1];
    if (!ORDER.includes(step)) return ctx.answerCbQuery();
    await ctx.answerCbQuery();
    await setUser(ctx, { state: `edit:${step}`, stateData: null });
    return askStep(ctx, step, 'edit');
  });

  const choice = (re, step, build) => bot.action(re, async (ctx) => {
    const [mode, cur] = stateOf(ctx);
    if (cur !== step) return ctx.answerCbQuery();
    await ctx.answerCbQuery();
    await ctx.deleteMessage().catch(() => {});
    return finish(ctx, mode, step, build(ctx.match[1]));
  });
  choice(/^gn:(MALE|FEMALE)$/, 'GENDER', (v) => ({ gender: v }));
  choice(/^lf:(MALE|FEMALE|ALL)$/, 'LOOKING', (v) => ({ lookingFor: v }));

  bot.action(/^rg:(\d+|all)$/, async (ctx) => {
    const [mode, cur] = stateOf(ctx);
    if (cur !== 'REGION') return ctx.answerCbQuery();
    const v = ctx.match[1];
    if (v !== 'all' && !REGIONS[Number(v)]) return ctx.answerCbQuery();
    await ctx.answerCbQuery();
    await ctx.deleteMessage().catch(() => {});
    return finish(ctx, mode, 'REGION', { region: v === 'all' ? null : REGIONS[Number(v)] });
  });

  bot.action(/^it:(\d+|done)$/, async (ctx) => {
    const [mode, cur] = stateOf(ctx);
    if (cur !== 'INTERESTS') return ctx.answerCbQuery();
    let sel = getData(ctx.user).sel || [];
    const v = ctx.match[1];
    if (v === 'done') {
      if (!sel.length && mode !== 'search') return ctx.answerCbQuery('❗ Kamida bitta qiziqish tanlang', { show_alert: true });
      await ctx.answerCbQuery();
      await ctx.deleteMessage().catch(() => {});
      return finish(ctx, mode, 'INTERESTS', { interests: sel.map((i) => INTERESTS[i]) });
    }
    const i = Number(v);
    if (sel.includes(i)) sel = sel.filter((x) => x !== i);
    else {
      if (sel.length >= 5) return ctx.answerCbQuery('❗ Eng ko‘pi bilan 5 ta tanlash mumkin', { show_alert: true });
      sel.push(i);
    }
    await setUser(ctx, { stateData: JSON.stringify({ sel }) });
    await ctx.answerCbQuery();
    return ctx.editMessageReplyMarkup(interestsKb(sel, mode).reply_markup).catch(() => {});
  });

  bot.action('cancel', async (ctx) => {
    await ctx.answerCbQuery();
    await ctx.deleteMessage().catch(() => {});
    const st = ctx.user.state || '';
    await setUser(ctx, { state: null, stateData: null });
    if (st.startsWith('search')) return showSearch(ctx);
    return ctx.reply('🏠 Asosiy menyu', mainMenu);
  });

  bot.action('x', async (ctx) => { await ctx.answerCbQuery(); return ctx.deleteMessage().catch(() => {}); });
}
