import { prisma } from '../db.js';
import { config } from '../config.js';
import { b, ikb, HTML, profileCaption, mainMenu } from '../ui.js';
import { esc, fmt, isAdmin, isPremium, setUser, getData, clearState, safe, sleep, startOfToday } from '../utils.js';

const SIZE = 8;
let lastBroadcast = 0;

const homeKb = ikb([
  [b('📊 Statistika', 'a:stats'), b('📈 Hisobotlar', 'a:rep')],
  [b('👥 Foydalanuvchilar', 'a:users:0'), b('🔎 Topish', 'a:find')],
  [b('🚩 Shikoyatlar', 'a:reports:0'), b('🛡 Tekshiruv', 'a:unv:0')],
  [b('📢 Xabar yuborish', 'a:bc'), b('💎 Premium', 'a:prem')],
]);
const backRow = [b('⬅️ Admin panel', 'a:home')];

async function panel(ctx) {
  if (ctx.callbackQuery) await ctx.deleteMessage().catch(() => {});
  return ctx.reply('🛠 <b>ZENO TANISHUV — Admin panel</b>', { ...HTML, ...homeKb });
}

function pager(cmd, page, total) {
  const pages = Math.max(1, Math.ceil(total / SIZE));
  const row = [];
  if (page > 0) row.push(b('‹', `a:${cmd}:${page - 1}`));
  row.push(b(`${page + 1}/${pages}`, 'x'));
  if (page + 1 < pages) row.push(b('›', `a:${cmd}:${page + 1}`));
  return row;
}

async function replaceMsg(ctx, text, kb) {
  if (ctx.callbackQuery) await ctx.deleteMessage().catch(() => {});
  return ctx.reply(text, { ...HTML, ...kb });
}

async function stats(ctx) {
  const now = new Date();
  const [all, done, male, female, prem, banned, pending, matches, likes, unv, pay] = await Promise.all([
    prisma.user.count(),
    prisma.user.count({ where: { completed: true } }),
    prisma.user.count({ where: { completed: true, gender: 'MALE' } }),
    prisma.user.count({ where: { completed: true, gender: 'FEMALE' } }),
    prisma.user.count({ where: { premiumUntil: { gt: now } } }),
    prisma.user.count({ where: { banned: true } }),
    prisma.report.count({ where: { status: 'PENDING' } }),
    prisma.match.count(),
    prisma.swipe.count({ where: { type: 'LIKE' } }),
    prisma.user.count({ where: { completed: true, verified: false, banned: false } }),
    prisma.payment.aggregate({ _sum: { stars: true }, _count: true }),
  ]);
  const online = await prisma.user.count({ where: { lastSeenAt: { gt: new Date(Date.now() - 24 * 3600_000) } } });
  return replaceMsg(ctx, `📊 <b>Statistika</b>

👥 Jami: <b>${all}</b> (to‘liq profil: <b>${done}</b>)
👨 Erkak: <b>${male}</b> • 👩 Ayol: <b>${female}</b>
🟢 24 soatda faol: <b>${online}</b>
💎 Premium: <b>${prem}</b>
🚫 Bloklangan: <b>${banned}</b>
🛡 Tekshirilmagan: <b>${unv}</b>
🚩 Kutilayotgan shikoyat: <b>${pending}</b>
❤️ Yoqtirishlar: <b>${likes}</b> • 💞 Moslik: <b>${matches}</b>
💰 To‘lovlar: <b>${pay._count}</b> ta, <b>${pay._sum.stars || 0} ⭐</b>`, ikb([backRow]));
}

async function report(ctx, period) {
  const since = period === 'day' ? startOfToday() : new Date(Date.now() - 30 * 86_400_000);
  const w = { createdAt: { gte: since } };
  const [users, likes, matches, reports, pay] = await Promise.all([
    prisma.user.count({ where: { ...w, completed: true } }),
    prisma.swipe.count({ where: { ...w, type: 'LIKE' } }),
    prisma.match.count({ where: w }),
    prisma.report.count({ where: w }),
    prisma.payment.aggregate({ where: w, _sum: { stars: true }, _count: true }),
  ]);
  return replaceMsg(ctx, `📈 <b>${period === 'day' ? 'Kunlik hisobot (bugun)' : 'Oylik hisobot (30 kun)'}</b>

🆕 Yangi foydalanuvchilar: <b>${users}</b>
❤️ Yoqtirishlar: <b>${likes}</b>
💞 Yangi moslik: <b>${matches}</b>
🚩 Shikoyatlar: <b>${reports}</b>
💰 To‘lovlar: <b>${pay._count}</b> ta — <b>${pay._sum.stars || 0} ⭐</b>`,
  ikb([[b('📅 Bugun', 'a:rpt:day'), b('🗓 30 kun', 'a:rpt:month')], backRow]));
}

async function usersList(ctx, page, cmd = 'users', where = { completed: true }, title = '👥 <b>Foydalanuvchilar</b>') {
  const [total, list] = await Promise.all([
    prisma.user.count({ where }),
    prisma.user.findMany({ where, orderBy: { id: 'desc' }, skip: page * SIZE, take: SIZE }),
  ]);
  const rows = list.map((u) => [b(`#${u.id} ${u.name || '—'}, ${u.age || '?'} ${u.banned ? '🚫' : ''}${u.verified ? '✅' : ''}${isPremium(u) ? '💎' : ''}`, `a:u:${u.id}`)]);
  rows.push(pager(cmd, page, total), backRow);
  return replaceMsg(ctx, `${title} — jami: <b>${total}</b>`, ikb(rows));
}

async function userView(ctx, id) {
  const u = await prisma.user.findUnique({
    where: { id },
    include: { _count: { select: { reportsIn: true, swipesOut: true, matchesA: true, matchesB: true } } },
  });
  if (!u) return ctx.reply('❗ Foydalanuvchi topilmadi.');
  if (ctx.callbackQuery) await ctx.deleteMessage().catch(() => {});
  const info = `${u.completed ? profileCaption(u) : '<i>Profil to‘ldirilmagan</i>'}

━━━━━━━━━━━━━━
🆔 #${u.id} • TG: <code>${u.tgId}</code>
${u.banned ? '🚫 BLOKLANGAN' : '🟢 Faol'} • ${u.verified ? '✅ Tasdiqlangan' : '⏳ Tekshirilmagan'}${u.hiddenByReports ? ' • 🙈 Shikoyat sabab yashirilgan' : ''}
💎 Premium: ${isPremium(u) ? fmt(u.premiumUntil) : 'yo‘q'}
🚩 Shikoyatlar: ${u._count.reportsIn} • ❤️ Yoqtirgan: ${u._count.swipesOut} • 💞 Moslik: ${u._count.matchesA + u._count.matchesB}
📅 Ro‘yxatdan: ${fmt(u.createdAt)}`;
  const kb = ikb([
    [b(u.verified ? '❎ Tasdiqni olish' : '✅ Tasdiqlash', `a:ver:${u.id}`), b(u.banned ? '♻️ Blokdan chiqarish' : '🚫 Bloklash', u.banned ? `a:unban:${u.id}` : `a:ban:${u.id}`)],
    [b('💎 +7 kun', `a:pr:${u.id}:7`), b('💎 +30 kun', `a:pr:${u.id}:30`), b('❌ Premiumni olish', `a:pr:${u.id}:0`)],
    [b('🗑 Profilni o‘chirish', `a:del:${u.id}`)],
    backRow,
  ]);
  if (u.photoId) {
    try { return await ctx.replyWithPhoto(u.photoId, { caption: info, ...HTML, ...kb }); } catch { /* matn bilan yuboriladi */ }
  }
  return ctx.reply(info, { ...HTML, ...kb });
}

async function reportsList(ctx, page) {
  const where = { status: 'PENDING' };
  const [total, list] = await Promise.all([
    prisma.report.count({ where }),
    prisma.report.findMany({ where, include: { target: true }, orderBy: { createdAt: 'asc' }, skip: page * SIZE, take: SIZE }),
  ]);
  const rows = list.map((r) => [b(`#${r.id} ${r.target.name || '—'} — ${r.reason}`, `a:r:${r.id}`)]);
  rows.push(pager('reports', page, total), backRow);
  return replaceMsg(ctx, `🚩 <b>Shikoyatlar</b> — kutilayotgan: <b>${total}</b>`, ikb(rows));
}

async function reportView(ctx, rid) {
  const r = await prisma.report.findUnique({ where: { id: rid }, include: { target: true, reporter: true } });
  if (!r) return ctx.reply('❗ Shikoyat topilmadi.');
  if (ctx.callbackQuery) await ctx.deleteMessage().catch(() => {});
  const total = await prisma.report.count({ where: { targetId: r.targetId, status: 'PENDING' } });
  const info = `🚩 <b>Shikoyat #${r.id}</b>\nSabab: <b>${esc(r.reason)}</b>\nShikoyatchi: #${r.reporter.id} ${esc(r.reporter.name || '')}\nUshbu profilga kutilayotgan shikoyatlar: <b>${total}</b>\n\n${profileCaption(r.target)}\n\n🆔 #${r.target.id} • TG: <code>${r.target.tgId}</code>`;
  const kb = ikb([
    [b('🚫 Bloklash', `a:ban:${r.targetId}`), b('🗑 O‘chirish', `a:del:${r.targetId}`)],
    [b('✅ Asossiz — rad etish', `a:rdis:${r.id}`)],
    [b('⬅️ Ro‘yxat', 'a:reports:0')],
  ]);
  try { return await ctx.replyWithPhoto(r.target.photoId, { caption: info, ...HTML, ...kb }); } catch { return ctx.reply(info, { ...HTML, ...kb }); }
}

const findUser = (x) => prisma.user.findFirst({
  where: { OR: [{ tgId: BigInt(x) }, { id: Number(x) < 2_147_483_647 ? Number(x) : -1 }] },
});

// ---------- Admin matn kiritishlari ----------
export async function onAdminText(ctx, step) {
  if (!isAdmin(ctx.from.id)) return;
  const t = ctx.message.text.trim();
  if (step === 'FIND') {
    await clearState(ctx);
    if (!/^\d+$/.test(t)) return ctx.reply('❗ Faqat raqam yuboring (ID yoki Telegram ID).');
    const u = await findUser(t);
    return u ? userView(ctx, u.id) : ctx.reply('❗ Foydalanuvchi topilmadi.');
  }
  if (step === 'PREM') {
    await clearState(ctx);
    const m = t.match(/^(\d+)\s+(\d{1,4})$/);
    if (!m) return ctx.reply('❗ Format: <code>ID kun</code> (masalan: <code>15 30</code>)', HTML);
    const u = await findUser(m[1]);
    if (!u) return ctx.reply('❗ Foydalanuvchi topilmadi.');
    const until = new Date(Math.max(Date.now(), u.premiumUntil?.getTime() || 0) + Number(m[2]) * 86_400_000);
    await prisma.user.update({ where: { id: u.id }, data: { premiumUntil: until } });
    await safe(() => ctx.telegram.sendMessage(Number(u.tgId), `💎 Sizga <b>${m[2]} kun</b> Premium berildi! Rahmat 💜`, HTML));
    return ctx.reply(`✅ #${u.id} ga Premium berildi — ${fmt(until)} gacha.`);
  }
  if (step === 'BC') {
    if (t.length > 3500) return ctx.reply('❗ Xabar juda uzun.');
    await setUser(ctx, { state: 'admin:BCCONFIRM', stateData: JSON.stringify({ text: t }) });
    const n = await prisma.user.count({ where: { completed: true, banned: false } });
    return ctx.reply(`📢 <b>Oldindan ko‘rish</b>\n\n${esc(t)}\n\n— — —\nQabul qiluvchilar: <b>${n}</b> ta`,
      { ...HTML, ...ikb([[b('✅ Yuborish', 'a:bcgo'), b('❌ Bekor qilish', 'a:home')]]) });
  }
}

export function register(bot) {
  bot.command('admin', async (ctx) => {
    if (!isAdmin(ctx.from.id)) return; // oddiy foydalanuvchiga hech narsa ko‘rsatilmaydi
    await clearState(ctx);
    return panel(ctx);
  });

  bot.action(/^a:(\w+)(?::(\w+))?(?::(\w+))?$/, async (ctx) => {
    if (!isAdmin(ctx.from.id)) return ctx.answerCbQuery('⛔').catch(() => {});
    await ctx.answerCbQuery().catch(() => {});
    const [, cmd, p1, p2] = ctx.match;
    const n1 = Number(p1);

    switch (cmd) {
      case 'home': await clearState(ctx); return panel(ctx);
      case 'stats': return stats(ctx);
      case 'rep': return report(ctx, 'day');
      case 'rpt': return report(ctx, p1 === 'month' ? 'month' : 'day');
      case 'users': return usersList(ctx, n1 || 0);
      case 'unv': return usersList(ctx, n1 || 0, 'unv', { completed: true, verified: false, banned: false }, '🛡 <b>Tekshirilmagan profillar</b>');
      case 'u': return userView(ctx, n1);
      case 'reports': return reportsList(ctx, n1 || 0);
      case 'r': return reportView(ctx, n1);

      case 'ver': {
        const u = await prisma.user.findUnique({ where: { id: n1 } });
        if (u) await prisma.user.update({ where: { id: n1 }, data: { verified: !u.verified } });
        return userView(ctx, n1);
      }
      case 'ban': {
        const u = await prisma.user.update({ where: { id: n1 }, data: { banned: true, state: null, stateData: null } });
        await prisma.match.updateMany({ where: { active: true, OR: [{ aId: n1 }, { bId: n1 }] }, data: { active: false, endedAt: new Date() } });
        await prisma.report.updateMany({ where: { targetId: n1, status: 'PENDING' }, data: { status: 'RESOLVED' } });
        await safe(() => ctx.telegram.sendMessage(Number(u.tgId), '🚫 Hisobingiz qoidabuzarlik sababli bloklandi.'));
        return userView(ctx, n1);
      }
      case 'unban':
        await prisma.user.update({ where: { id: n1 }, data: { banned: false, hiddenByReports: false } });
        return userView(ctx, n1);
      case 'del': {
        return replaceMsg(ctx, `🗑 #${n1} profilini butunlay o‘chirasizmi? Bu amalni qaytarib bo‘lmaydi.`,
          ikb([[b('✅ Ha, o‘chirish', `a:delyes:${n1}`), b('❌ Yo‘q', `a:u:${n1}`)]]));
      }
      case 'delyes': {
        const u = await prisma.user.findUnique({ where: { id: n1 } });
        if (u) {
          await prisma.user.delete({ where: { id: n1 } });
          await safe(() => ctx.telegram.sendMessage(Number(u.tgId), '🗑 Profilingiz qoidalarga mos kelmagani uchun o‘chirildi. Qayta ro‘yxatdan o‘tish uchun /start ni bosing.'));
        }
        return replaceMsg(ctx, `✅ #${n1} o‘chirildi.`, ikb([backRow]));
      }
      case 'rdis': {
        const r = await prisma.report.findUnique({ where: { id: n1 } });
        if (r) {
          await prisma.report.updateMany({ where: { targetId: r.targetId, status: 'PENDING' }, data: { status: 'DISMISSED' } });
          await prisma.user.update({ where: { id: r.targetId }, data: { hiddenByReports: false } });
        }
        return reportsList(ctx, 0);
      }
      case 'pr': { // a:pr:<id>:<kun>
        const u = await prisma.user.findUnique({ where: { id: n1 } });
        if (!u) return;
        const days = Number(p2);
        const until = days === 0 ? null : new Date(Math.max(Date.now(), u.premiumUntil?.getTime() || 0) + days * 86_400_000);
        await prisma.user.update({ where: { id: n1 }, data: { premiumUntil: until } });
        if (until) await safe(() => ctx.telegram.sendMessage(Number(u.tgId), `💎 Sizga <b>${days} kun</b> Premium berildi! 💜`, HTML));
        return userView(ctx, n1);
      }

      case 'find':
        await setUser(ctx, { state: 'admin:FIND', stateData: null });
        return ctx.reply('🔎 Foydalanuvchi ID yoki Telegram ID raqamini yuboring:');
      case 'prem':
        await setUser(ctx, { state: 'admin:PREM', stateData: null });
        return ctx.reply('💎 Premium berish.\nFormat: <code>ID kun</code>\nMasalan: <code>15 30</code> (ID — bot ID’si yoki Telegram ID)', HTML);
      case 'bc':
        await setUser(ctx, { state: 'admin:BC', stateData: null });
        return ctx.reply('📢 Barcha foydalanuvchilarga yuboriladigan xabar matnini yozing:');

      case 'bcgo': {
        const d = getData(ctx.user);
        if (ctx.user.state !== 'admin:BCCONFIRM' || !d.text) return;
        const wait = config.broadcastCooldownMin * 60_000 - (Date.now() - lastBroadcast);
        if (wait > 0) return ctx.reply(`⏳ Ommaviy xabar cheklovi: ${Math.ceil(wait / 60_000)} daqiqadan keyin urinib ko‘ring.`);
        lastBroadcast = Date.now();
        await clearState(ctx);
        const users = await prisma.user.findMany({ where: { completed: true, banned: false }, select: { tgId: true } });
        await ctx.reply(`📤 Yuborish boshlandi: ${users.length} ta foydalanuvchi.`);
        const adminId = ctx.from.id;
        (async () => { // orqa fonda, Telegram limitidan oshmaslik uchun ~20 xabar/soniya
          let ok = 0; let fail = 0;
          for (const u of users) {
            (await safe(() => ctx.telegram.sendMessage(Number(u.tgId), d.text))) ? ok++ : fail++;
            await sleep(50);
          }
          await safe(() => ctx.telegram.sendMessage(adminId, `✅ Yuborish yakunlandi.\nYetkazildi: ${ok}\nYetkazilmadi: ${fail}`));
        })();
        return;
      }
    }
  });
}
