import { prisma } from '../db.js';
import { b, ikb, HTML, mainMenu, chatMenu, BACK, profileCaption, chatCtrlKb } from '../ui.js';
import { esc, safe, setUser, hasContactInfo } from '../utils.js';

async function getMatchFor(me, id) {
  const m = await prisma.match.findUnique({ where: { id }, include: { a: true, b: true } });
  if (!m || !m.active || (m.aId !== me.id && m.bId !== me.id)) return null;
  return { m, other: m.aId === me.id ? m.b : m.a };
}

export async function showChats(ctx) {
  const me = ctx.user;
  const matches = await prisma.match.findMany({
    where: { active: true, OR: [{ aId: me.id }, { bId: me.id }] },
    include: { a: true, b: true },
    orderBy: { createdAt: 'desc' },
    take: 30,
  });
  if (!matches.length) {
    return ctx.reply('💬 Hozircha suhbatlar yo‘q.\n\nO‘zaro moslik bo‘lgach, shu yerda suhbatlar paydo bo‘ladi 💜', mainMenu);
  }
  const rows = matches.map((m) => {
    const o = m.aId === me.id ? m.b : m.a;
    return [b(`💬 ${o.name}, ${o.age}`, `chat:${m.id}`)];
  });
  return ctx.reply('💬 <b>Suhbatlarim</b>\n\nSuhbatni tanlang:', { ...HTML, ...ikb(rows) });
}

async function endMatch(ctx, m, other, reasonText) {
  await prisma.match.update({ where: { id: m.id }, data: { active: false, endedAt: new Date() } });
  await prisma.user.updateMany({ where: { id: { in: [m.aId, m.bId] }, state: `chat:${m.id}` }, data: { state: null, stateData: null } });
  if (reasonText) await safe(() => ctx.telegram.sendMessage(Number(other.tgId), reasonText, { ...HTML, ...mainMenu }));
}

export async function relayText(ctx, matchId) {
  const me = ctx.user;
  const text = ctx.message.text.trim();
  if (text === BACK) {
    await setUser(ctx, { state: null, stateData: null });
    return ctx.reply('🏠 Asosiy menyu', mainMenu);
  }
  const r = await getMatchFor(me, matchId);
  if (!r) {
    await setUser(ctx, { state: null, stateData: null });
    return ctx.reply('❗ Bu suhbat yakunlangan.', mainMenu);
  }
  if (hasContactInfo(text)) {
    return ctx.reply('🔒 Xavfsizlik uchun telefon raqam, havola va @username yuborish taqiqlangan.');
  }
  if (text.length > 1000) return ctx.reply('❗ Xabar juda uzun (1000 belgigacha).');
  return deliver(ctx, r, (chatId, extra) => ctx.telegram.sendMessage(chatId, `💬 <b>${esc(me.name)}</b>\n${esc(text)}`, { ...extra }));
}

export async function relayPhoto(ctx, matchId) {
  const me = ctx.user;
  const r = await getMatchFor(me, matchId);
  if (!r) {
    await setUser(ctx, { state: null, stateData: null });
    return ctx.reply('❗ Bu suhbat yakunlangan.', mainMenu);
  }
  const fileId = ctx.message.photo.at(-1).file_id;
  const caption = ctx.message.caption;
  if (caption && hasContactInfo(caption)) return ctx.reply('🔒 Rasm izohida telefon raqam, havola yoki @username bo‘lishi mumkin emas.');
  return deliver(ctx, r, (chatId, extra) => ctx.telegram.sendPhoto(chatId, fileId, {
    ...extra, caption: `💬 <b>${esc(me.name)}</b>${caption ? `\n${esc(caption)}` : ''}`,
  }));
}

async function deliver(ctx, { m, other }, send) {
  const extra = { ...HTML, protect_content: true };
  if (other.state !== `chat:${m.id}`) Object.assign(extra, ikb([[b('↩️ Javob berish', `chat:${m.id}`)]]));
  const ok = await safe(() => send(Number(other.tgId), extra));
  if (!ok) return ctx.reply('⚠️ Xabar yetkazilmadi. Foydalanuvchi botni to‘xtatgan bo‘lishi mumkin.');
}

export function register(bot) {
  bot.action(/^chat:(\d+)$/, async (ctx) => {
    const r = await getMatchFor(ctx.user, Number(ctx.match[1]));
    if (!r) return ctx.answerCbQuery('Suhbat mavjud emas yoki yakunlangan', { show_alert: true });
    await ctx.answerCbQuery();
    await setUser(ctx, { state: `chat:${r.m.id}`, stateData: null });
    await ctx.reply(
      `💬 <b>${esc(r.other.name)}</b> bilan suhbat boshlandi.\n\nMatn yoki rasm yuboring — xabaringiz bot orqali yetkaziladi.\n🔒 <i>Telefon raqam, havola va @username almashish taqiqlangan.</i>`,
      { ...HTML, ...chatMenu },
    );
    const kb = chatCtrlKb(r.m.id, r.other.id);
    try {
      return await ctx.replyWithPhoto(r.other.photoId, { caption: profileCaption(r.other), ...HTML, protect_content: true, ...kb });
    } catch {
      return ctx.reply(profileCaption(r.other), { ...HTML, ...kb });
    }
  });

  // Suhbatni to‘xtatish (tasdiqlash bilan)
  bot.action(/^ce:(\d+)(?::(y))?$/, async (ctx) => {
    const r = await getMatchFor(ctx.user, Number(ctx.match[1]));
    if (!r) return ctx.answerCbQuery('Suhbat allaqachon yakunlangan', { show_alert: true });
    if (!ctx.match[2]) {
      await ctx.answerCbQuery();
      return ctx.reply('🛑 Suhbatni to‘xtatmoqchimisiz? Qayta yozish uchun yana moslik kerak bo‘ladi.',
        ikb([[b('✅ Ha, to‘xtatish', `ce:${r.m.id}:y`), b('❌ Yo‘q', 'x')]]));
    }
    await ctx.answerCbQuery();
    await endMatch(ctx, r.m, r.other, `🛑 <b>${esc(ctx.user.name)}</b> suhbatni to‘xtatdi.`);
    await ctx.deleteMessage().catch(() => {});
    ctx.user.state = null;
    return ctx.reply('🛑 Suhbat to‘xtatildi.', mainMenu);
  });

  // Bloklash (tasdiqlash bilan)
  bot.action(/^cx:(\d+):(\d+)(?::(y))?$/, async (ctx) => {
    const me = ctx.user;
    const otherId = Number(ctx.match[1]);
    const mid = Number(ctx.match[2]);
    if (!ctx.match[3]) {
      await ctx.answerCbQuery();
      return ctx.reply('🚫 Foydalanuvchini bloklaysizmi? U sizga boshqa ko‘rinmaydi va yoza olmaydi.',
        ikb([[b('✅ Ha, bloklash', `cx:${otherId}:${mid}:y`), b('❌ Yo‘q', 'x')]]));
    }
    await prisma.block.upsert({
      where: { blockerId_blockedId: { blockerId: me.id, blockedId: otherId } },
      create: { blockerId: me.id, blockedId: otherId }, update: {},
    });
    const m = await prisma.match.findUnique({ where: { id: mid } });
    if (m?.active) {
      const other = await prisma.user.findUnique({ where: { id: otherId } });
      await endMatch(ctx, m, other, null);
    }
    await ctx.answerCbQuery('🚫 Bloklandi');
    await ctx.deleteMessage().catch(() => {});
    ctx.user.state = null;
    return ctx.reply('🚫 Foydalanuvchi bloklandi.', mainMenu);
  });

  bot.action('mychats', async (ctx) => { await ctx.answerCbQuery(); return showChats(ctx); });
}
