import { prisma } from '../db.js';
import { config } from '../config.js';
import { b, ikb, HTML, mainMenu, LOOK_TXT, RULES } from '../ui.js';
import { setUser } from '../utils.js';
import { askStep } from './profile.js';

export async function showSettings(ctx, edit = false) {
  const u = ctx.user;
  const text = `⚙️ <b>Sozlamalar</b>\n\n👁 Profil: ${u.visible ? 'ko‘rinadi ✅' : 'yashirilgan ⛔'}\n🔔 Bildirishnomalar: ${u.notify ? 'yoqilgan ✅' : 'o‘chirilgan ⛔'}\n🎯 Qidiraman: ${LOOK_TXT[u.lookingFor]}`;
  const kb = ikb([
    [b(u.visible ? '⛔ Profilni yashirish' : '✅ Profilni ko‘rsatish', 'st:vis')],
    [b(u.notify ? '🔕 Bildirishnomani o‘chirish' : '🔔 Bildirishnomani yoqish', 'st:ntf')],
    [b('🎯 Kimni qidiraman', 'st:look')],
    [b('📜 Qoidalar', 'st:rules'), b('🆘 Yordam', 'st:help')],
    [b('🗑 Hisobni o‘chirish', 'st:del')],
  ]);
  if (edit) return ctx.editMessageText(text, { ...HTML, ...kb }).catch(() => {});
  return ctx.reply(text, { ...HTML, ...kb });
}

export function register(bot) {
  bot.action(/^st:(\w+)$/, async (ctx) => {
    const k = ctx.match[1];
    const u = ctx.user;
    await ctx.answerCbQuery();
    switch (k) {
      case 'vis': await setUser(ctx, { visible: !u.visible }); return showSettings(ctx, true);
      case 'ntf': await setUser(ctx, { notify: !u.notify }); return showSettings(ctx, true);
      case 'look':
        await setUser(ctx, { state: 'edit:LOOKING', stateData: null });
        return askStep(ctx, 'LOOKING', 'edit');
      case 'rules': return ctx.reply(RULES, HTML);
      case 'help':
        return ctx.reply(`🆘 <b>Yordam</b>\n\nSavol yoki muammo bo‘lsa${config.support ? `, @${config.support} ga yozing` : ', administratorga murojaat qiling'}.\nQoidabuzarlik haqida profil ostidagi «🚩 Shikoyat» tugmasi orqali xabar bering.`, HTML);
      case 'del':
        return ctx.reply('🗑 <b>Hisobni o‘chirish</b>\n\nBarcha ma’lumotlaringiz (profil, yoqtirishlar, suhbatlar) butunlay o‘chiriladi. Bu amalni qaytarib bo‘lmaydi. Davom etasizmi?',
          { ...HTML, ...ikb([[b('✅ Ha, o‘chirish', 'st:delyes'), b('❌ Yo‘q', 'x')]]) });
      case 'delyes':
        await prisma.user.delete({ where: { id: u.id } });
        await ctx.deleteMessage().catch(() => {});
        return ctx.reply('✅ Hisobingiz va barcha ma’lumotlaringiz o‘chirildi. Qaytmoqchi bo‘lsangiz /start ni bosing.', { reply_markup: { remove_keyboard: true } });
    }
  });
}
