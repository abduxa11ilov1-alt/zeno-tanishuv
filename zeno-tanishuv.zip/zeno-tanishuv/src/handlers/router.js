import { message } from 'telegraf/filters';
import { MENU_HANDLERS } from './menu.js';
import { startRegistration, onStepText, onPhoto } from './profile.js';
import { relayText, relayPhoto } from './chat.js';
import { onAdminText } from './admin.js';
import { clearState, isAdmin } from '../utils.js';
import { mainMenu } from '../ui.js';

const split = (u) => (u.state || '').split(':');

export function register(bot) {
  bot.on(message('text'), async (ctx) => {
    const text = ctx.message.text.trim();
    const u = ctx.user;
    if (text.startsWith('/')) return ctx.reply('❓ Noma’lum buyruq. /menu ni bosing.');

    if (u.state?.startsWith('admin:') && isAdmin(ctx.from.id)) return onAdminText(ctx, split(u)[1]);

    if (!u.completed) {
      if (u.state?.startsWith('reg:')) return onStepText(ctx, 'reg', split(u)[1]);
      return startRegistration(ctx);
    }

    if (MENU_HANDLERS[text]) {
      await clearState(ctx);
      return MENU_HANDLERS[text](ctx);
    }

    const [kind, arg] = split(u);
    switch (kind) {
      case 'edit':
      case 'search': return onStepText(ctx, kind, arg);
      case 'chat': return relayText(ctx, Number(arg));
      default: return ctx.reply('👇 Iltimos, menyudan tanlang.', mainMenu);
    }
  });

  bot.on(message('photo'), async (ctx) => {
    const u = ctx.user;
    const [kind, arg] = split(u);
    if ((kind === 'reg' || kind === 'edit') && arg === 'PHOTO') return onPhoto(ctx, kind);
    if (kind === 'chat') return relayPhoto(ctx, Number(arg));
    if (kind === 'reg' || kind === 'edit' || kind === 'search') return ctx.reply('❗ Hozir rasm emas, matn yoki tugma orqali javob bering.');
    return ctx.reply('👇 Iltimos, menyudan tanlang.', u.completed ? mainMenu : undefined);
  });

  bot.on('message', async (ctx) => {
    const [kind] = split(ctx.user);
    if (kind === 'chat') return ctx.reply('❗ Suhbatda faqat matn va rasm yuborish mumkin.');
    if (ctx.user.state?.endsWith('PHOTO')) return ctx.reply('📸 Iltimos, oddiy rasm yuboring.');
  });
}
