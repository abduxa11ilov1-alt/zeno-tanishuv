import { prisma } from '../db.js';
import { b, ikb, HTML, mainMenu } from '../ui.js';
import { isPremium } from '../utils.js';
import { sendCard } from './browse.js';

const SIZE = 8;

async function render(ctx, { title, items, total, page, src, navCb, empty }) {
  if (ctx.callbackQuery) await ctx.deleteMessage().catch(() => {});
  if (!total) return ctx.reply(empty, { ...HTML, ...mainMenu });
  const pages = Math.ceil(total / SIZE);
  const rows = items.map((u) => [b(`${u.name}, ${u.age} • ${u.region || ''}`, `vp:${u.id}:${src}`)]);
  const nav = [];
  if (page > 0) nav.push(b('‹ Oldingi', `${navCb}:${page - 1}`));
  nav.push(b(`${page + 1}/${pages}`, 'x'));
  if (page + 1 < pages) nav.push(b('Keyingi ›', `${navCb}:${page + 1}`));
  rows.push(nav);
  return ctx.reply(`${title} — jami: <b>${total}</b>`, { ...HTML, ...ikb(rows) });
}

export async function showLiked(ctx, page = 0) {
  const where = { fromId: ctx.user.id, type: 'LIKE', toUser: { completed: true, banned: false } };
  const [total, rows] = await Promise.all([
    prisma.swipe.count({ where }),
    prisma.swipe.findMany({ where, include: { toUser: true }, orderBy: { createdAt: 'desc' }, skip: page * SIZE, take: SIZE }),
  ]);
  return render(ctx, { title: '❤️ <b>Yoqtirganlarim</b>', items: rows.map((r) => r.toUser), total, page, src: 'L', navCb: 'll', empty: '❤️ Siz hali hech kimni yoqtirmagansiz.\n«❤️ Tanishuvni boshlash» tugmasini bosing!' });
}

export async function showFavs(ctx, page = 0) {
  const where = { ownerId: ctx.user.id, target: { completed: true, banned: false } };
  const [total, rows] = await Promise.all([
    prisma.favorite.count({ where }),
    prisma.favorite.findMany({ where, include: { target: true }, orderBy: { createdAt: 'desc' }, skip: page * SIZE, take: SIZE }),
  ]);
  return render(ctx, { title: '⭐ <b>Sevimlilar</b>', items: rows.map((r) => r.target), total, page, src: 'F', navCb: 'fl', empty: '⭐ Sevimlilar ro‘yxati bo‘sh.\nProfil ostidagi «⭐ Sevimlilarga qo‘shish» tugmasidan foydalaning.' });
}

export async function showReceived(ctx, page = 0) {
  const me = ctx.user;
  const where = {
    toId: me.id, type: 'LIKE',
    fromUser: {
      completed: true, banned: false, visible: true,
      swipesIn: { none: { fromId: me.id } },
      blocksIn: { none: { blockerId: me.id } },
      blocksOut: { none: { blockedId: me.id } },
    },
  };
  const total = await prisma.swipe.count({ where });
  if (!isPremium(me)) {
    if (ctx.callbackQuery) await ctx.deleteMessage().catch(() => {});
    return ctx.reply(
      total
        ? `💌 Sizni <b>${total}</b> kishi yoqtirgan!\n\n💎 Kim yoqtirganini ko‘rish uchun Premium tarifga o‘ting.\n<i>Yoki «❤️ Tanishuvni boshlash» orqali ularni uchratishingiz mumkin.</i>`
        : '💌 Hozircha sizni yoqtirganlar yo‘q. Profilingizni to‘ldiring va faol bo‘ling — yaqinda yoqtirishadi 💜',
      { ...HTML, ...ikb(total ? [[b('💎 Premium olish', 'prem:open')]] : []) },
    );
  }
  const rows = await prisma.swipe.findMany({ where, include: { fromUser: true }, orderBy: { createdAt: 'desc' }, skip: page * SIZE, take: SIZE });
  return render(ctx, { title: '💌 <b>Sizni yoqtirganlar</b>', items: rows.map((r) => r.fromUser), total, page, src: 'R', navCb: 'rl', empty: '💌 Hozircha yangi yoqtirganlar yo‘q.' });
}

export function register(bot) {
  bot.action(/^ll:(\d+)$/, async (ctx) => { await ctx.answerCbQuery(); return showLiked(ctx, Number(ctx.match[1])); });
  bot.action(/^fl:(\d+)$/, async (ctx) => { await ctx.answerCbQuery(); return showFavs(ctx, Number(ctx.match[1])); });
  bot.action(/^rl:(\d+)$/, async (ctx) => { await ctx.answerCbQuery(); return showReceived(ctx, Number(ctx.match[1])); });

  bot.action(/^vp:(\d+):([LFR])$/, async (ctx) => {
    const src = ctx.match[2];
    if (src === 'R' && !isPremium(ctx.user)) return ctx.answerCbQuery('💎 Faqat Premium uchun', { show_alert: true });
    const t = await prisma.user.findUnique({ where: { id: Number(ctx.match[1]) } });
    if (!t || t.banned || !t.completed) return ctx.answerCbQuery('Profil topilmadi');
    await ctx.answerCbQuery();
    await ctx.deleteMessage().catch(() => {});
    return sendCard(ctx, t, src);
  });
}
