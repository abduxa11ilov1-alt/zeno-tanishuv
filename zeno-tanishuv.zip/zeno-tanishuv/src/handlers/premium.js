import { message } from 'telegraf/filters';
import { prisma } from '../db.js';
import { config } from '../config.js';
import { b, ikb, HTML } from '../ui.js';
import { esc, fmt, isPremium, setUser, today, notifyAdmins } from '../utils.js';

export async function showPremium(ctx) {
  const u = ctx.user;
  const P = config.products;
  const L = config.limits;
  const status = isPremium(u) ? `✅ Faol — <b>${fmt(u.premiumUntil)}</b> gacha` : '🆓 Bepul tarif';
  const freeBoost = isPremium(u) && u.freeBoostDate !== today();
  const text = `💎 <b>ZENO PREMIUM</b>

Holatingiz: ${status}

<b>🆓 Bepul tarif</b>
• 👀 Kuniga ${L.free.views} ta profil
• ❤️ Kuniga ${L.free.likes} ta yoqtirish
• ⭐ ${L.free.favorites} ta sevimli

<b>💎 Premium</b>
• 👀 Kuniga ${L.premium.views} ta profil
• 💌 Kim yoqtirganini ko‘rish
• 🚀 Profilni yuqoriga chiqarish (kuniga 1 marta bepul)
• 🔎 Kengaytirilgan qidiruv (tuman va qiziqishlar)
• ❤️ Kuniga ${L.premium.likes} ta yoqtirish, ${L.premium.favorites} ta sevimli

💳 To‘lov Telegram Stars (⭐) orqali. Premium <b>faqat tasdiqlangan to‘lovdan keyin</b> faollashadi.`;
  const rows = [
    [b(`⭐ 7 kun — ${P.P7.stars} ⭐`, 'buy:P7')],
    [b(`⭐ 30 kun — ${P.P30.stars} ⭐`, 'buy:P30')],
    [b(`⭐ 90 kun — ${P.P90.stars} ⭐`, 'buy:P90')],
    [b(freeBoost ? '🚀 Profilni yuqoriga chiqarish (bepul)' : `🚀 Profilni yuqoriga chiqarish — ${P.BOOST.stars} ⭐`, 'boost')],
  ];
  return ctx.reply(text, { ...HTML, ...ikb(rows) });
}

const invoice = (ctx, kind) => {
  const p = config.products[kind];
  return ctx.replyWithInvoice({
    title: p.title,
    description: kind === 'BOOST'
      ? 'Profilingiz 3 soat davomida boshqalarga ko‘proq ko‘rsatiladi.'
      : 'Ko‘proq profil, kim yoqtirganini ko‘rish, kengaytirilgan qidiruv va boshqa imkoniyatlar.',
    payload: `${kind}:${ctx.user.id}`,
    provider_token: '',
    currency: 'XTR',
    prices: [{ label: p.title, amount: p.stars }],
  });
};

export function register(bot) {
  bot.action('prem:open', async (ctx) => { await ctx.answerCbQuery(); return showPremium(ctx); });

  bot.action(/^buy:(P7|P30|P90)$/, async (ctx) => { await ctx.answerCbQuery(); return invoice(ctx, ctx.match[1]); });

  bot.action('boost', async (ctx) => {
    const u = ctx.user;
    if (isPremium(u) && u.freeBoostDate !== today()) {
      const until = new Date(Math.max(Date.now(), u.boostUntil?.getTime() || 0) + config.products.BOOST.hours * 3600_000);
      await setUser(ctx, { boostUntil: until, freeBoostDate: today() });
      return ctx.answerCbQuery('🚀 Profilingiz 3 soatga yuqoriga chiqarildi!', { show_alert: true });
    }
    await ctx.answerCbQuery();
    return invoice(ctx, 'BOOST');
  });

  // To‘lovdan oldin tekshiruv
  bot.on('pre_checkout_query', async (ctx) => {
    const q = ctx.preCheckoutQuery;
    const [kind, uid] = q.invoice_payload.split(':');
    const prod = config.products[kind];
    const ok = prod && Number(uid) === ctx.user.id && q.currency === 'XTR' && q.total_amount === prod.stars;
    return ctx.answerPreCheckoutQuery(!!ok, ok ? undefined : 'Buyurtma yaroqsiz. Qaytadan urinib ko‘ring.');
  });

  // Faqat HAQIQIY tasdiqlangan to‘lovdan keyin faollashtirish
  bot.on(message('successful_payment'), async (ctx) => {
    const p = ctx.message.successful_payment;
    const [kind] = p.invoice_payload.split(':');
    const prod = config.products[kind];
    if (!prod || p.currency !== 'XTR') return;
    if (await prisma.payment.findUnique({ where: { chargeId: p.telegram_payment_charge_id } })) return; // takroriy

    const u = ctx.user;
    const now = Date.now();
    const data = kind === 'BOOST'
      ? { boostUntil: new Date(Math.max(now, u.boostUntil?.getTime() || 0) + prod.hours * 3600_000) }
      : { premiumUntil: new Date(Math.max(now, u.premiumUntil?.getTime() || 0) + prod.days * 86_400_000) };

    const [, updated] = await prisma.$transaction([
      prisma.payment.create({ data: { userId: u.id, kind, stars: p.total_amount, chargeId: p.telegram_payment_charge_id } }),
      prisma.user.update({ where: { id: u.id }, data }),
    ]);
    ctx.user = updated;
    await ctx.reply(kind === 'BOOST'
      ? '🚀 <b>To‘lov tasdiqlandi!</b> Profilingiz 3 soatga yuqoriga chiqarildi.'
      : `💎 <b>To‘lov tasdiqlandi!</b> Premium <b>${fmt(updated.premiumUntil)}</b> gacha faol. Rahmat! 💜`, HTML);
    await notifyAdmins(ctx, `💰 Yangi to‘lov: <b>${esc(u.name || 'Noma’lum')}</b> (#${u.id}) — ${prod.title}, ${p.total_amount} ⭐`);
  });
}
