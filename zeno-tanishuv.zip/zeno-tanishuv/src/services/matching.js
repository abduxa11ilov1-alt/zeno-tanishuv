import { prisma } from '../db.js';
import { config } from '../config.js';
import { isPremium, isBoosted } from '../utils.js';

export const limitsFor = (u) => (isPremium(u) ? config.limits.premium : config.limits.free);

function baseWhere(me) {
  const w = {
    id: { not: me.id },
    completed: true,
    visible: true,
    banned: false,
    hiddenByReports: false,
    swipesIn: { none: { fromId: me.id } },        // oldin ko‘rsatilganlar qayta chiqmaydi
    blocksIn: { none: { blockerId: me.id } },     // men bloklaganlar
    blocksOut: { none: { blockedId: me.id } },    // meni bloklaganlar
    OR: [{ lookingFor: 'ALL' }, { lookingFor: me.gender }], // ular ham mening jinsimni qidirsin
  };
  if (me.lookingFor !== 'ALL') w.gender = me.lookingFor;
  return w;
}

export async function nextCandidate(me, useFilters = false) {
  const where = baseWhere(me);
  if (useFilters) {
    where.age = { gte: me.fMinAge, lte: me.fMaxAge };
    if (me.fGender !== 'ALL') where.gender = me.fGender;
    if (me.fRegion) where.region = me.fRegion;
    if (isPremium(me)) { // kengaytirilgan qidiruv
      if (me.fDistrict) where.district = { contains: me.fDistrict, mode: 'insensitive' };
      if (me.fInterests.length) where.interests = { hasSome: me.fInterests };
    }
  }
  const list = await prisma.user.findMany({ where, take: 60, orderBy: { lastSeenAt: 'desc' } });
  if (!list.length) return null;
  const boosted = list.filter(isBoosted);
  const pool = boosted.length && Math.random() < 0.5 ? boosted : list; // yuqoriga chiqarilganlar ko‘proq ko‘rinadi
  return pool[Math.floor(Math.random() * pool.length)];
}

export async function likeUser(me, targetId) {
  const target = await prisma.user.findUnique({ where: { id: targetId } });
  if (!target || target.banned || !target.completed) return { status: 'gone' };

  const blocked = await prisma.block.findFirst({
    where: { OR: [{ blockerId: me.id, blockedId: targetId }, { blockerId: targetId, blockedId: me.id }] },
  });
  if (blocked) return { status: 'gone' };

  const prev = await prisma.swipe.findUnique({ where: { fromId_toId: { fromId: me.id, toId: targetId } } });
  if (prev?.type === 'LIKE') return { status: 'already', target };

  await prisma.swipe.upsert({
    where: { fromId_toId: { fromId: me.id, toId: targetId } },
    create: { fromId: me.id, toId: targetId, type: 'LIKE' },
    update: { type: 'LIKE' },
  });

  const back = await prisma.swipe.findUnique({ where: { fromId_toId: { fromId: targetId, toId: me.id } } });
  if (back?.type === 'LIKE') {
    const [aId, bId] = me.id < targetId ? [me.id, targetId] : [targetId, me.id];
    const match = await prisma.match.upsert({ where: { aId_bId: { aId, bId } }, create: { aId, bId }, update: {} });
    return { status: 'match', match, target };
  }
  return { status: 'liked', target };
}
