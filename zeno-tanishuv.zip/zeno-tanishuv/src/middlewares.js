import { prisma } from './db.js';
import { today } from './utils.js';

// ---- Spamga qarshi: 10 soniyada 20 tadan ko‘p harakat qilsa to‘xtatiladi ----
const hits = new Map();
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of hits) if (now - v.t > 60_000) hits.delete(k);
}, 60_000).unref();

export async function rateLimit(ctx, next) {
  const id = ctx.from?.id;
  if (!id) return next();
  const now = Date.now();
  const h = hits.get(id) || { n: 0, t: now, warned: false };
  if (now - h.t > 10_000) Object.assign(h, { n: 0, t: now, warned: false });
  h.n++;
  hits.set(id, h);
  if (h.n > 20) {
    if (!h.warned) {
      h.warned = true;
      await ctx.reply('⏳ Juda tez harakat qilyapsiz. Iltimos, biroz kuting.').catch(() => {});
    }
    return;
  }
  return next();
}

// ---- Foydalanuvchini bazadan yuklash, bloklanganlarni to‘xtatish, kunlik hisoblagichlarni yangilash ----
export async function loadUser(ctx, next) {
  if (!ctx.from || ctx.from.is_bot) return;
  if (ctx.chat && ctx.chat.type !== 'private') return;

  const tgId = BigInt(ctx.from.id);
  let user = await prisma.user.upsert({ where: { tgId }, create: { tgId }, update: {} });

  if (user.banned) {
    if (ctx.callbackQuery) await ctx.answerCbQuery('🚫 Hisobingiz bloklangan.', { show_alert: true }).catch(() => {});
    else if (ctx.message) await ctx.reply('🚫 Hisobingiz qoidabuzarlik sababli bloklangan.').catch(() => {});
    return;
  }

  const data = {};
  const d = today();
  if (user.counterDate !== d) Object.assign(data, { counterDate: d, viewsToday: 0, likesToday: 0 });
  if (Date.now() - user.lastSeenAt.getTime() > 300_000) data.lastSeenAt = new Date();
  if (Object.keys(data).length) user = await prisma.user.update({ where: { id: user.id }, data });

  ctx.user = user;
  return next();
}
