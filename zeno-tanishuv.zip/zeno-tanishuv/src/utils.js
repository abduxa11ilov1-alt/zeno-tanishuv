import { prisma } from './db.js';
import { config } from './config.js';

export const esc = (s = '') => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
export const isPremium = (u) => !!u?.premiumUntil && u.premiumUntil > new Date();
export const isBoosted = (u) => !!u?.boostUntil && u.boostUntil > new Date();
export const isAdmin = (id) => config.adminIds.includes(Number(id));
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// O‘zbekiston vaqti (UTC+5) bo‘yicha sana: "YYYY-MM-DD"
export const today = () => new Date(Date.now() + 5 * 3600 * 1000).toISOString().slice(0, 10);
export const startOfToday = () => new Date(`${today()}T00:00:00+05:00`);
export const fmt = (d) => (d ? new Date(d.getTime() + 5 * 3600 * 1000).toISOString().slice(0, 16).replace('T', ' ') : '—');

// Telefon raqam, @username va havolalarni aniqlash (shaxsiy ma'lumot almashinuvini cheklash)
const CONTACT_RE = /(\+?\d[\d\s().-]{7,}\d)|@[a-z0-9_]{4,}|https?:\/\/|t\.me\/|www\.|\b[a-z0-9-]+\.(com|uz|ru|org|net|me|io)\b/i;
export const hasContactInfo = (t = '') => CONTACT_RE.test(t);

export async function safe(fn) {
  try {
    return await fn();
  } catch (e) {
    if (e?.response?.error_code !== 403) console.error('⚠️ Yuborishda xato:', e.message);
    return null;
  }
}

export async function setUser(ctx, data) {
  ctx.user = await prisma.user.update({ where: { id: ctx.user.id }, data });
  return ctx.user;
}

export const getData = (u) => {
  try { return JSON.parse(u.stateData || '{}'); } catch { return {}; }
};

export async function clearState(ctx) {
  if (ctx.user.state || ctx.user.stateData) return setUser(ctx, { state: null, stateData: null });
  return ctx.user;
}

export async function notifyAdmins(ctx, text, extra = {}) {
  for (const id of config.adminIds) await safe(() => ctx.telegram.sendMessage(id, text, { parse_mode: 'HTML', ...extra }));
}
