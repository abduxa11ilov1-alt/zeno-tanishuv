import { Markup } from 'telegraf';
import { esc, isPremium } from './utils.js';

export const MENU = {
  START: '❤️ Tanishuvni boshlash',
  SEARCH: '🔍 Odamlarni qidirish',
  PROFILE: '👤 Mening profilim',
  EDIT: '✏️ Profilni tahrirlash',
  LIKED: '❤️ Yoqtirganlarim',
  RECEIVED: '💌 Menga yoqqanlar',
  CHATS: '💬 Suhbatlarim',
  FAVS: '⭐ Sevimlilar',
  SETTINGS: '⚙️ Sozlamalar',
  PREMIUM: '💎 Premium',
};
export const BACK = '⬅️ Orqaga';
export const HTML = { parse_mode: 'HTML' };
export const b = (t, d) => Markup.button.callback(t, d);
export const ikb = (rows) => Markup.inlineKeyboard(rows);

export const mainMenu = Markup.keyboard([
  [MENU.START, MENU.SEARCH],
  [MENU.PROFILE, MENU.EDIT],
  [MENU.LIKED, MENU.RECEIVED],
  [MENU.CHATS, MENU.FAVS],
  [MENU.SETTINGS, MENU.PREMIUM],
]).resize();
export const chatMenu = Markup.keyboard([[BACK]]).resize();

export const GENDER_TXT = { MALE: '👨 Erkak', FEMALE: '👩 Ayol' };
export const LOOK_TXT = { MALE: '👨 Erkaklar', FEMALE: '👩 Ayollar', ALL: '👥 Farqi yo‘q' };

export function profileCaption(u) {
  const badges = `${u.verified ? ' ✅' : ''}${isPremium(u) ? ' 💎' : ''}`;
  const loc = [u.region, u.district].filter(Boolean).map(esc).join(', ') || '—';
  const ints = u.interests?.length ? u.interests.join(' • ') : '—';
  return `💜 <b>${esc(u.name)}</b>, ${u.age}${badges}\n📍 ${loc}\n🎯 ${ints}\n\n━━━━━━━━━━━━━━\n💬 ${esc(u.bio)}`;
}

// Profil kartochkasi tugmalari. m: b=tanishuv, s=qidiruv, L=yoqtirganlarim, F=sevimlilar, R=menga yoqqanlar
export function cardKb(id, m) {
  const rep = b('🚩 Shikoyat qilish', `rp:${id}:${m}`);
  const fav = b('⭐ Sevimlilarga qo‘shish', `fv:${id}:${m}`);
  switch (m) {
    case 'L': return ikb([[b('💔 Yoqtirishni bekor qilish', `ul:${id}`)], [fav], [rep], [b('⬅️ Orqaga', 'll:0')]]);
    case 'F': return ikb([[b('❤️ Yoqdi', `lk:${id}:F`), b('🗑 Olib tashlash', `fd:${id}`)], [rep], [b('⬅️ Orqaga', 'fl:0')]]);
    case 'R': return ikb([[b('❤️ Yoqdi', `lk:${id}:R`), b('👎 O‘tkazib yuborish', `sk:${id}:R`)], [fav], [rep], [b('⬅️ Orqaga', 'rl:0')]]);
    default: return ikb([[b('❤️ Yoqdi', `lk:${id}:${m}`), b('👎 O‘tkazib yuborish', `sk:${id}:${m}`)], [fav, rep]]);
  }
}

export const chatCtrlKb = (mid, otherId) => ikb([
  [b('🛑 Suhbatni to‘xtatish', `ce:${mid}`), b('🚫 Bloklash', `cx:${otherId}:${mid}`)],
  [b('🚩 Shikoyat qilish', `rp:${otherId}:c${mid}`)],
]);
export const kbFor = (id, src) => (src.startsWith('c') ? chatCtrlKb(Number(src.slice(1)), id) : cardKb(id, src));

export const CONSENT_TEXT = `💜 <b>ZENO TANISHUV</b> botiga xush kelibsiz!

Davom etishdan oldin quyidagilar bilan tanishing:

• Bot faqat <b>18 yosh va undan katta</b> shaxslar uchun.
• Ism, yosh, jins, hudud, qiziqishlar, qisqa ma’lumot va rasmingiz <b>faqat tanishuv maqsadida</b> boshqa foydalanuvchilarga ko‘rsatiladi.
• Telefon raqamingiz va Telegram ID/username’ingiz boshqalarga <b>hech qachon</b> oshkor qilinmaydi.
• Haqoratli, soxta yoki aldamchi profillar bloklanadi.
• Ma’lumotlaringizni istalgan vaqtda «⚙️ Sozlamalar» orqali butunlay o‘chirishingiz mumkin.

Shartlarga rozimisiz?`;

export const RULES = `📜 <b>Qoidalar va maxfiylik</b>

1️⃣ Bot faqat 18+ yoshdagilar uchun.
2️⃣ Faqat o‘z haqiqiy ma’lumotlaringiz va rasmingizni kiriting.
3️⃣ Haqorat, spam, reklama, firibgarlik qat’iyan taqiqlanadi.
4️⃣ Suhbatda telefon raqam, havola va @username yuborish mumkin emas — bu sizning xavfsizligingiz uchun.
5️⃣ Shaxsiy ma’lumotlaringiz (telefon, Telegram ID) hech kimga ko‘rsatilmaydi.
6️⃣ Qoidabuzarlik haqida «🚩 Shikoyat» tugmasi orqali xabar bering.
7️⃣ Hisobingizni istalgan vaqt o‘chirishingiz mumkin — barcha ma’lumotlar bazadan butunlay o‘chiriladi.`;
