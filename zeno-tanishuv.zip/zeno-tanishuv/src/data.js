export const REGIONS = [
  'Toshkent shahri', 'Toshkent viloyati', 'Andijon', 'Buxoro', 'Farg‘ona', 'Jizzax', 'Xorazm',
  'Namangan', 'Navoiy', 'Qashqadaryo', 'Qoraqalpog‘iston', 'Samarqand', 'Sirdaryo', 'Surxondaryo',
];

export const INTERESTS = [
  '🎵 Musiqa', '🎬 Kino', '📚 Kitob', '✈️ Sayohat', '⚽ Sport', '🎮 Geymerlik', '🍳 Oshpazlik', '📸 Foto',
  '💻 Texnologiya', '🎨 San‘at', '🐾 Hayvonlar', '🧘 Yoga', '🏋️ Fitnes', '🚗 Avtomobil', '💃 Raqs', '📈 Biznes',
];
