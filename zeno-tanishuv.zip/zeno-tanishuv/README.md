# 💜 ZENO TANISHUV — Telegram tanishuv boti

Node.js · Telegraf.js · PostgreSQL · Prisma ORM. Barcha interfeys o‘zbek tilida.

## Imkoniyatlar
- Ro‘yxatdan o‘tish (rozilik, 18+ cheklov, ism, yosh, jins, hudud, qiziqish, bio, rasm) — holat bazada saqlanadi
- Tanishuv: ❤️ Yoqdi / 👎 O‘tkazish / ⭐ Sevimli / 🚩 Shikoyat; o‘zaro moslik xabari
- Qidiruv filtrlari: yosh, jins, viloyat, tuman, qiziqish (tuman va qiziqish — Premium)
- Ko‘rilgan profil qayta chiqmaydi
- Anonim suhbat: xabarlar bot orqali o‘tadi, telefon/ID/@username oshkor bo‘lmaydi (kontakt almashish filtrlanadi, `protect_content` yoqilgan)
- Bloklash, suhbatni to‘xtatish, shikoyat (3 ta shikoyatda profil avtomatik yashiriladi)
- Premium (Telegram Stars ⭐): faqat `successful_payment` tasdiqlangandan so‘ng faollashadi, takroriy to‘lov himoyasi bor
- Admin panel `/admin`: foydalanuvchilar, bloklash, shikoyatlar, tekshiruv, o‘chirish, ommaviy xabar (cheklov bilan), Premium boshqaruvi, statistika, kunlik/oylik hisobot
- Spamga qarshi: tezlik limiti, kunlik yoqtirish/ko‘rish limitlari, ommaviy xabar cheklovi

## 1. Tayyorgarlik
1. **Bot yaratish:** Telegramda @BotFather → `/newbot` → nom: `ZENO TANISHUV` → tokenni oling.
2. **Admin ID:** @userinfobot orqali o‘z Telegram ID’ingizni bilib oling.
3. **Node.js 18.18+** va **PostgreSQL 14+** kerak.

## 2. O‘rnatish (oddiy usul)
```bash
cd zeno-tanishuv
npm install
cp .env.example .env        # BOT_TOKEN, ADMIN_IDS, DATABASE_URL ni to‘ldiring
npm run db:push             # jadvallarni yaratadi
npm start
```
Bazani tez ko‘tarish: `docker run -d --name zeno-db -e POSTGRES_USER=zeno -e POSTGRES_PASSWORD=zeno_pass -e POSTGRES_DB=zeno -p 5432:5432 -v zeno_pg:/var/lib/postgresql/data postgres:16-alpine`
yoki bepul bulutli: Neon / Supabase / Railway (ulanish manzilini `DATABASE_URL` ga qo‘ying).

## 3. Docker bilan (tavsiya etiladi, 24/7)
```bash
cp .env.example .env        # BOT_TOKEN va ADMIN_IDS ni yozing
docker compose up -d --build
docker compose logs -f bot
```
Baza ma’lumotlari `zeno_pgdata` volume’ida saqlanadi — qayta ishga tushganda yo‘qolmaydi.

## 4. PM2 bilan (VPS)
```bash
npm install -g pm2
pm2 start ecosystem.config.cjs
pm2 save && pm2 startup
```

## 5. Bulutli hosting (Railway / Render / Fly.io)
- Repozitoriyni ulang, PostgreSQL qo‘shing, o‘zgaruvchilarni kiriting.
- Start buyrug‘i: `npx prisma db push && npm start`
- Webhook uchun: `WEBHOOK_DOMAIN=https://sizning-domen.up.railway.app`, `WEBHOOK_SECRET=<tasodifiy_qator>` (bo‘sh bo‘lsa long polling ishlaydi).
- Production’da migratsiyalar uchun: lokal `npm run db:migrate:dev -- --name init`, serverda `npm run db:migrate`.

## 6. Premium to‘lovi (Telegram Stars)
Narxlar `.env` da (`PRICE_P7`, `PRICE_P30`, `PRICE_P90`, `PRICE_BOOST`). Stars uchun alohida provayder kerak emas.
To‘lov oqimi: `sendInvoice (XTR)` → `pre_checkout_query` tekshiruvi → `successful_payment` → tranzaksiya ichida to‘lov yozuvi + Premium faollashtirish.
Yig‘ilgan Stars’ni @BotFather → Bot Settings → Balance orqali yechib olasiz. Boshqa to‘lov tizimi (Click/Payme) kerak bo‘lsa, `premium.js` ga provayder tokeni bilan fiat invoice qo‘shish mumkin.

## 7. Admin
`/admin` — faqat `ADMIN_IDS` dagilar uchun. Oddiy foydalanuvchiga buyruq javob bermaydi.

## 8. Loyiha tuzilishi
```
prisma/schema.prisma        # ma’lumotlar bazasi sxemasi
src/index.js                # kirish nuqtasi (polling/webhook)
src/config.js  db.js  data.js  utils.js  ui.js  middlewares.js
src/services/matching.js    # nomzod tanlash, yoqtirish, moslik
src/handlers/
  menu.js profile.js search.js browse.js lists.js
  chat.js report.js premium.js settings.js admin.js router.js
```

## 9. Xavfsizlik va moderatsiya eslatmalari
- 18 yoshdan kichiklar ro‘yxatdan o‘ta olmaydi; «Voyaga yetmagan» shikoyati profilni darhol yashiradi.
- Bio va suhbatda telefon/havola/@username bloklanadi. Suhbat matnlari bazada **saqlanmaydi** (maxfiylik).
- Haqiqiy ishlab chiqarishda: shaxsiy ma’lumotlar siyosatini (maxfiylik) yuridik jihatdan rasmiylashtiring, rasmlarni muntazam moderatsiya qiling (`🛡 Tekshiruv`), `.env` ni hech qachon ommaga chiqarmang.
